"""Instala o plugin Gestão de CS neste computador.

O que este arquivo faz, na ordem:
  1. Confere o Python e se a pasta não é temporária.
  2. Instala as bibliotecas: openpyxl e xlsxwriter (necessárias), scikit-learn e python-pptx (opcionais).
  3. Registra o plugin no Claude Code, apontando para a pasta gestao-de-cs, que fica ao lado deste arquivo.
  4. Roda uma conferência rápida com a empresa de exemplo.

Nada é enviado para fora, além do download das bibliotecas. Para desfazer: python instalar.py --desfazer
"""

import argparse
import glob
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
PLUGIN = AQUI / "gestao-de-cs"
NOME = "gestao-de-cs"
CHAVE = f"{NOME}@{NOME}"
NECESSARIAS = {"openpyxl": "openpyxl", "xlsxwriter": "xlsxwriter"}
OPCIONAIS = {"sklearn": "scikit-learn", "pptx": "python-pptx"}
PYTHON_MINIMO = (3, 10)


def parar(mensagem):
    print(f"\nPAROU: {mensagem}")
    sys.exit(1)


def rodar(comando, tempo=600, entrada=None):
    return subprocess.run(
        comando, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=tempo, input=entrada
    )


def pasta_temporaria():
    texto = str(AQUI).lower().replace("\\", "/")
    temp = str(Path(tempfile.gettempdir()).resolve()).lower().replace("\\", "/")
    return texto.startswith(temp) or ".zip/" in texto or "/temp/" in texto


def versao_do(caminho):
    """Devolve a versão desse Python, ou None."""
    try:
        r = rodar([caminho, "-c", "import sys; print('%d.%d' % sys.version_info[:2])"], tempo=30)
    except (OSError, subprocess.SubprocessError):
        return None
    if r.returncode != 0:
        return None  # o atalho da Microsoft Store existe, mas não é o Python de verdade
    try:
        return tuple(int(p) for p in r.stdout.strip().split("."))
    except ValueError:
        return None


def achar_python():
    """O plugin chama `python` pelo PATH. É nesse Python que as bibliotecas precisam entrar.

    Devolve o caminho completo: no Windows, abrir só "python" pode cair no Python que rodou
    este arquivo, em vez do que está no PATH.
    """
    for comando in ("python", "python3"):
        caminho = shutil.which(comando)
        versao = versao_do(caminho) if caminho else None
        if versao and versao >= PYTHON_MINIMO:
            if comando == "python3":
                print("Aviso: aqui só existe o comando python3. No Mac e no Linux, crie um atalho chamado python.")
            print(f"Python {versao[0]}.{versao[1]}: ok")
            return caminho
    parar(
        "não achei o Python 3.10 ou mais novo no PATH. Sem ele, o plugin não roda e a trava de privacidade não funciona.\n"
        "Instale em python.org e, no Windows, marque 'Add python.exe to PATH' na primeira tela. Depois, abra uma sessão nova."
    )


def falta(python, modulos):
    teste = "import importlib.util, sys; sys.exit(0 if importlib.util.find_spec(sys.argv[1]) else 1)"
    return [pacote for modulo, pacote in modulos.items() if rodar([python, "-c", teste, modulo], tempo=60).returncode != 0]


def instalar_bibliotecas(python):
    for modulos, necessaria in ((NECESSARIAS, True), (OPCIONAIS, False)):
        pacotes = falta(python, modulos)
        if not pacotes:
            print(f"Bibliotecas {', '.join(modulos.values())}: ok")
            continue
        print(f"Instalando {', '.join(pacotes)}...")
        r = rodar([python, "-m", "pip", "install", "--disable-pip-version-check", "--quiet", *pacotes])
        if r.returncode == 0:
            print("  instaladas")
        elif necessaria:
            parar(f"não consegui instalar {', '.join(pacotes)}.\n{r.stderr.strip()[-600:]}")
        else:
            print(f"  Aviso: {', '.join(pacotes)} ficou de fora. Sem isso, não saem previsões nem PowerPoint; o resto funciona.")


def achar_claude():
    """O comando claude do terminal ou, no Windows, o que vem junto com o app."""
    comando = shutil.which("claude")
    if comando:
        return comando
    appdata = os.environ.get("APPDATA")
    if appdata:
        achados = glob.glob(os.path.join(appdata, "Claude", "claude-code", "*", "*", "claude.exe"))
        if achados:
            return max(achados, key=os.path.getmtime)
    return None


def caminho_settings():
    pasta = os.environ.get("CLAUDE_CONFIG_DIR")
    return Path(pasta) / "settings.json" if pasta else Path.home() / ".claude" / "settings.json"


def ler_settings(caminho):
    if not caminho.exists():
        return {}
    try:
        dados = json.loads(caminho.read_text(encoding="utf-8-sig"))
    except (ValueError, OSError) as erro:
        parar(f"não consegui ler {caminho} e não mexi nele: {erro}")
    if not isinstance(dados, dict):
        parar(f"{caminho} não tem o formato esperado, e não mexi nele.")
    return dados


def gravar_settings(caminho, dados):
    caminho.parent.mkdir(parents=True, exist_ok=True)
    temporario = caminho.with_name(caminho.name + ".novo")
    temporario.write_text(json.dumps(dados, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(temporario, caminho)


def registrado(caminho):
    dados = ler_settings(caminho)
    fonte = dados.get("extraKnownMarketplaces", {}).get(NOME, {}).get("source", {})
    return dados.get("enabledPlugins", {}).get(CHAVE) is True and fonte.get("path") == str(PLUGIN)


def registrar_direto(caminho):
    """Para quem não tem o comando claude: grava no settings.json as mesmas duas chaves que ele gravaria."""
    dados = ler_settings(caminho)
    if caminho.exists():
        copia = caminho.with_name(caminho.name + ".antes-do-gestao-de-cs")
        if not copia.exists():
            shutil.copy2(caminho, copia)
            print(f"Cópia do arquivo original: {copia}")
    dados.setdefault("extraKnownMarketplaces", {})[NOME] = {"source": {"source": "directory", "path": str(PLUGIN)}}
    dados.setdefault("enabledPlugins", {})[CHAVE] = True
    gravar_settings(caminho, dados)


def registrar():
    caminho = caminho_settings()
    claude = achar_claude()
    if claude:
        rodar([claude, "plugin", "uninstall", CHAVE], tempo=120)
        rodar([claude, "plugin", "marketplace", "remove", NOME], tempo=120)
        rodar([claude, "plugin", "marketplace", "add", str(PLUGIN)], tempo=120)
        rodar([claude, "plugin", "install", CHAVE], tempo=120)
        if registrado(caminho):
            print("Plugin registrado no Claude Code")
            return
        print("O comando do Claude Code não concluiu o registro. Vou gravar direto na configuração.")
    registrar_direto(caminho)
    if not registrado(caminho):
        parar(f"não consegui registrar o plugin em {caminho}.")
    print("Plugin registrado na configuração do Claude Code")


def conferir(python):
    cs = PLUGIN / "scripts" / "cs.py"
    exemplo = PLUGIN / "exemplos" / "empresa-exemplo"
    r = rodar([python, str(cs), "validar", "--pasta", str(exemplo)], tempo=120)
    if r.returncode != 0:
        parar(f"o script do plugin não rodou na empresa de exemplo.\n{(r.stderr or r.stdout).strip()[-600:]}")
    trava = PLUGIN / "scripts" / "guarda_privacidade.py"
    entrada = json.dumps({"tool_name": "Read", "tool_input": {"file_path": str(cs)}, "cwd": str(AQUI)})
    r = rodar([python, str(trava)], tempo=60, entrada=entrada)
    if r.returncode != 0:
        parar(f"a trava de privacidade não rodou.\n{(r.stderr or r.stdout).strip()[-600:]}")
    print("Conferência com a empresa de exemplo: ok")


def desfazer():
    caminho = caminho_settings()
    claude = achar_claude()
    if claude:
        rodar([claude, "plugin", "uninstall", CHAVE], tempo=120)
        rodar([claude, "plugin", "marketplace", "remove", NOME], tempo=120)
    dados = ler_settings(caminho)
    mudou = dados.get("enabledPlugins", {}).pop(CHAVE, None) is not None
    mudou = dados.get("extraKnownMarketplaces", {}).pop(NOME, None) is not None or mudou
    if mudou:
        gravar_settings(caminho, dados)
    print("Plugin retirado do Claude Code. Abra uma sessão nova para valer.")
    print("Esta pasta e as pastas das empresas continuam aqui: apague quando quiser. As bibliotecas do Python também ficam.")


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description="Instala o plugin Gestão de CS")
    parser.add_argument("--desfazer", action="store_true", help="retira o plugin do Claude Code")
    parser.add_argument("--qualquer-pasta", action="store_true", help="aceita rodar de uma pasta temporária")
    args = parser.parse_args()
    if args.desfazer:
        desfazer()
        return
    if not (PLUGIN / ".claude-plugin" / "plugin.json").exists():
        parar(f"não achei a pasta do plugin em {PLUGIN}. Extraia o zip inteiro e rode de novo.")
    if pasta_temporaria() and not args.qualquer_pasta:
        parar(
            f"esta pasta é temporária: {AQUI}\n"
            "O plugin é lido daqui, então ele sumiria junto. Extraia o zip para Documentos e rode de novo."
        )
    python = achar_python()
    instalar_bibliotecas(python)
    registrar()
    conferir(python)
    print(f"\nPRONTO. O plugin é lido de {PLUGIN}: não mova essa pasta.")
    print("Abra uma sessão NOVA do Claude Code e digite: /gestao-de-cs:consultor")


if __name__ == "__main__":
    main()
